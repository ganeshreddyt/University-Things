#include<stdio.h>
void main()
{
 int a,b = 20, c = 30;	
 printf("hello");
 }
