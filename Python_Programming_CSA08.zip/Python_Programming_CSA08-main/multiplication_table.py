#Multiplication table

num = int(input('Enter a positive integer:'))
for i in range(1,11):
    print(num,'*',i,'=',num*i)
