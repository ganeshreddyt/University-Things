#Program to check the string is palindrome or not....

string = input("Enter a string :")

duplicate = string[ : :-1]     #To reverse a string.......

print(duplicate)    
