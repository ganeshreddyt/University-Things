# Ganesh-Reddy
Day wise python programs
